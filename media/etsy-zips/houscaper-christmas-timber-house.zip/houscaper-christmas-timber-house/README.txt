HOUSCAPER - Christmas Timber House (laser-cut model)
======================================================

Thank you for your purchase!

WHICH FOLDER?
  3mm/  for 3 mm MDF or plywood  (33 parts, 4 sheets)
  2mm/  for 2 mm MDF or plywood  (33 parts, 4 sheets)
  Measure your stock with calipers and use the closest folder.

IN EACH FOLDER
  sheet-01.svg ...   cut sheets, 279 x 495 mm (11 x 19.5 in)
  sheet-01.dxf ...   same sheets as DXF
  fit-coupon.svg     cut this first on an offcut to check slot fit
  parts-list.csv     every part with its size
  *-assembly-guide.pdf   illustrated step-by-step guide

LASER SETUP
  Red lines (#FF0000) = cut      Blue lines (#0000FF) = engrave / score
  Import at 100% scale (units: mm). The 50 mm bar at the bottom-left of each sheet checks the scale.
  Paths are drawn at nominal size. Set kerf offset in your laser software
  using the fit coupon: pick the slot where the tab is snug, not forced.

FINISHED SIZE  about 19 x 12 x 24 cm (W x D x H)

LICENSE
  For personal use. You may cut and build as many as you like for yourself
  and as gifts. Please don't resell, share or upload the digital files.

Make your own house design: https://houscaper.xyz
